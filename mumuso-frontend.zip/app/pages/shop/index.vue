<template>
  <ShopLayoutPage title="Shop" sub-title="Discover our amazing products" />
</template>
