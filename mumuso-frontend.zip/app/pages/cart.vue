<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900">
    <UContainer class="py-8">
      <!-- Page Header -->
      <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900 dark:text-white mb-2">Shopping Cart</h1>
        <p class="text-gray-600 dark:text-gray-400">
          {{ cartItems?.length || 0 }} {{ cartItems?.length === 1 ? 'item' : 'items' }} in your cart
        </p>
      </div>

      <!-- Empty Cart State -->
      <div
          v-if="!cartItems || cartItems.length === 0"
          class="flex flex-col items-center justify-center py-16 text-center"
      >
        <div class="bg-gray-100 dark:bg-gray-800 rounded-full p-8 mb-6">
          <UIcon name="i-heroicons-shopping-cart" class="text-6xl text-gray-400"/>
        </div>
        <h3 class="text-2xl font-semibold text-gray-900 dark:text-white mb-2">Your cart is empty</h3>
        <p class="text-gray-500 dark:text-gray-400 mb-6">Looks like you haven't added anything to your cart yet</p>
        <UButton to="/shop" size="lg" icon="i-heroicons-shopping-bag">
          Continue Shopping
        </UButton>
      </div>

      <!-- Cart Content -->
      <div v-else class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Cart Items (Left Side - 2 columns) -->
        <div class="lg:col-span-2 space-y-4">
          <div
              v-for="item in cartItems"
              :key="`${item.slug}-${item.variation_id || 'default'}`"
              class="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div class="flex gap-4">
              <!-- Product Image -->
              <NuxtLink :to="`/shop/product/${item.product.slug}`" class="flex-shrink-0">
                <NuxtImg
                    :src="item.variation?.images?.thumb || item.product.image || 'https://placehold.co/120x120'"
                    :alt="item.variation?.name || item.product.name"
                    class="w-24 h-24 object-cover rounded-lg hover:opacity-90 transition-opacity"
                    width="120"
                    height="120"
                    loading="lazy"
                    format="webp"
                />
              </NuxtLink>

              <!-- Product Details -->
              <div class="flex-1 min-w-0">
                <!-- Product Name & Price -->
                <div class="flex justify-between items-start mb-2">
                  <div class="flex-1 min-w-0 pr-4">
                    <NuxtLink
                        :to="`/shop/product/${item.product.slug}`"
                        class="font-semibold text-gray-900 dark:text-white hover:text-primary-500 block truncate"
                    >
                      {{ item?.product?.name }}
                    </NuxtLink>
                    <!-- Variation Name -->
                    <p v-if="item.variation" class="text-sm font-medium text-primary-600 dark:text-primary-400 mt-1">
                      {{ item.variation.name }}
                    </p>
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                      SKU: {{ item.variation?.sku || item?.product?.sku }}
                    </p>
                  </div>
                  <div class="text-right flex-shrink-0">
                    <div class="space-y-1">
                      <!-- Item Total -->
                      <p class="font-bold text-lg text-gray-900 dark:text-white">
                        ${{ getItemTotal(item).toFixed(2) }}
                      </p>
                      <!-- Original Total (if discount) -->
                      <p v-if="hasDiscount(item)" class="text-sm text-gray-400 line-through">
                        ${{ getItemOriginalTotal(item).toFixed(2) }}
                      </p>
                      <!-- Price per unit -->
                      <div class="flex items-center gap-2 justify-end">
                        <p class="text-sm font-medium text-gray-900 dark:text-white">
                          ${{ getItemPrice(item).toFixed(2) }} each
                        </p>
                        <p v-if="hasDiscount(item)" class="text-xs text-gray-400 line-through">
                          ${{ getItemOriginalPrice(item).toFixed(2) }}
                        </p>
                      </div>
                      <!-- Discount Badge -->
                      <UBadge v-if="item.discount" color="success" variant="soft" size="xs">
                        {{ item.discount.summary }}
                      </UBadge>
                    </div>
                  </div>
                </div>

                <!-- Stock Status -->
                <div v-if="getStockStatus(getItemStock(item)).showBadge" class="mb-2">
                  <UBadge
                      :color="getStockStatus(getItemStock(item)).color"
                      variant="soft"
                      size="xs"
                  >
                    {{ getStockStatus(getItemStock(item)).message }}
                  </UBadge>
                </div>

                <!-- Quantity Controls & Remove Button -->
                <div class="flex items-center justify-between mt-3">
                  <div class="flex items-center gap-3">
                    <span class="text-sm text-gray-600 dark:text-gray-400">Quantity:</span>
                    <div class="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                      <UButton
                          @click="decrementQuantity(item)"
                          icon="i-heroicons-minus"
                          size="xs"
                          color="secondary"
                          variant="ghost"
                          :disabled="!canDecrementQuantity(item)"
                      />
                      <span class="text-sm font-semibold w-10 text-center text-gray-900 dark:text-white">
                        {{ item.quantity }}
                      </span>
                      <UButton
                          @click="incrementQuantity(item, getItemStock(item))"
                          icon="i-heroicons-plus"
                          size="xs"
                          color="secondary"
                          variant="ghost"
                          :disabled="!canIncrementQuantity(item)"
                      />
                    </div>
                  </div>

                  <UButton
                      @click="removeItemFromCart(item)"
                      icon="i-heroicons-trash"
                      size="sm"
                      color="error"
                      variant="ghost"
                  >
                    Remove
                  </UButton>
                </div>

                <!-- Max Stock Warning -->
                <p v-if="isMaxStockReached(item)" class="text-xs text-orange-500 mt-2">
                  <UIcon name="i-heroicons-exclamation-triangle" class="inline"/>
                  Maximum available quantity reached
                </p>
              </div>
            </div>
          </div>

          <!-- Continue Shopping Button -->
          <div class="pt-4">
            <UButton to="/shop" variant="soft" icon="i-heroicons-arrow-left" size="lg">
              Continue Shopping
            </UButton>
          </div>
        </div>

        <!-- Order Summary (Right Side - 1 column) -->
        <div class="lg:col-span-1">
          <div class="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm sticky top-4">
            <h2 class="text-xl font-bold text-gray-900 dark:text-white mb-6">Order Summary</h2>

            <!-- Applied Discounts Section -->
            <div v-if="appliedDiscounts && appliedDiscounts.length > 0" class="mb-6 pb-6 border-b border-gray-200 dark:border-gray-700">
              <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-2">
                <UIcon name="i-heroicons-tag" class="text-green-500" />
                Active Discounts
              </h3>
              <div class="space-y-3">
                <div v-for="discount in appliedDiscounts" :key="discount.name" class="bg-green-50 dark:bg-green-900/20 rounded-lg p-3">
                  <div class="flex items-start justify-between gap-2 mb-1">
                    <div class="flex-1 min-w-0">
                      <p class="text-sm font-semibold text-green-700 dark:text-green-300">{{ discount.name }}</p>
                      <p class="text-xs text-gray-600 dark:text-gray-400">{{ discount.summary }}</p>
                    </div>
                    <UBadge color="success" variant="solid" size="xs">
                      -${{ discount.discount_amount.toFixed(2) }}
                    </UBadge>
                  </div>
                  <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Applied to {{ discount.items_affected }} {{ discount.items_affected === 1 ? 'item' : 'items' }}
                  </p>
                </div>
              </div>
            </div>

            <!-- Price Breakdown -->
            <div class="space-y-3 mb-6">
              <!-- Original Subtotal (if discount) -->
              <div v-if="cartDiscount > 0" class="flex justify-between text-gray-500 dark:text-gray-400">
                <span>Original Subtotal</span>
                <span class="font-medium line-through">${{ cartOriginalTotal.toFixed(2) }}</span>
              </div>

              <!-- Subtotal (after discounts) -->
              <div class="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Subtotal</span>
                <span class="font-medium">${{ subtotal.toFixed(2) }}</span>
              </div>

              <!-- Backend Discount -->
              <div v-if="cartSavings > 0" class="flex justify-between text-green-600 dark:text-green-400">
                <span class="flex items-center gap-1">
                  <UIcon name="i-heroicons-tag" class="text-sm" />
                  Discount Savings
                </span>
                <span class="font-medium">-${{ cartSavings.toFixed(2) }}</span>
              </div>

              <!-- Shipping -->
              <div class="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Shipping</span>
                <span class="font-medium">
                  {{ shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}` }}
                </span>
              </div>

              <!-- Tax -->
              <div class="flex justify-between text-gray-600 dark:text-gray-400">
                <span>Tax ({{ taxRate }}%)</span>
                <span class="font-medium">${{ tax.toFixed(2) }}</span>
              </div>
            </div>

            <!-- Free Shipping Progress -->
            <div v-if="shipping > 0 && subtotal < freeShippingThreshold" class="mb-6">
              <div class="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
                <div class="flex items-start gap-2 mb-2">
                  <UIcon name="i-heroicons-truck" class="text-blue-500 mt-0.5"/>
                  <p class="text-sm text-blue-700 dark:text-blue-300">
                    Add ${{ (freeShippingThreshold - subtotal).toFixed(2) }} more for FREE shipping!
                  </p>
                </div>
                <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div
                      class="bg-blue-500 h-2 rounded-full transition-all duration-300"
                      :style="{ width: `${(subtotal / freeShippingThreshold) * 100}%` }"
                  ></div>
                </div>
              </div>
            </div>

            <!-- Total -->
            <div class="pt-4 border-t-2 border-gray-200 dark:border-gray-700 mb-6">
              <div class="flex justify-between items-baseline">
                <span class="text-lg font-semibold text-gray-900 dark:text-white">Total</span>
                <span class="text-2xl font-bold text-primary-500">${{ total.toFixed(2) }}</span>
              </div>
            </div>

            <!-- Checkout Button -->
            <UButton
                @click="handleCheckout"
                size="xl"
                block
                icon="i-heroicons-lock-closed"
                class="mb-4"
            >
              Proceed to Checkout
            </UButton>

            <!-- Security Badges -->
            <div class="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <div class="flex items-center gap-2">
                <UIcon name="i-heroicons-shield-check" class="text-green-500"/>
                <span>Secure checkout</span>
              </div>
              <div class="flex items-center gap-2">
                <UIcon name="i-heroicons-arrow-path" class="text-blue-500"/>
                <span>30-day return policy</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </UContainer>
  </div>
</template>

<script setup lang="ts">

const toast = useToast()
const router = useRouter()

const {
  cartItems,
  cartTotal,
  cartOriginalTotal,
  cartDiscount,
  cartSavings,
  appliedDiscounts,
  cartItemsCount,
  isLoading,
  updateCartItemQuantity,
  removeFromCart,
  clearCart,
  checkout
} = useCart()

// Constants
const taxRate = 10 // 10% tax
const freeShippingThreshold = 50
const shippingRate = 5.99

// Computed values - use backend discount data
const subtotal = computed(() => {
  // Use cart total which already includes backend discounts
  return cartTotal.value || 0
})

const shipping = computed(() => {
  return calculateShipping(subtotal.value, freeShippingThreshold, shippingRate)
})

const tax = computed(() => {
  return calculateTax(subtotal.value, taxRate)
})

const total = computed(() => {
  return calculateOrderTotal(subtotal.value, shipping.value, tax.value)
})

// Methods
const incrementQuantity = (item: any, maxStock: number) => {
  if (item && canIncrementQuantity(item)) {
    updateCartItemQuantity(item.product?.slug || item.slug, item.quantity + 1, item.variation_id)
  }
}

const decrementQuantity = (item: any) => {
  if (item && canDecrementQuantity(item)) {
    updateCartItemQuantity(item.product?.slug || item.slug, item.quantity - 1, item.variation_id)
  }
}

const removeItemFromCart = (item: any) => {
  if (item) {
    removeFromCart(item.product?.slug || item.slug, item.variation_id)
    toast.add({
      title: 'Removed from cart',
      description: `${item.product.name}${item.variation ? ' - ' + item.variation.name : ''} has been removed`,
      color: 'success',
      icon: 'i-heroicons-trash'
    })
  }
}

// Helper to get item price (after discount)
const getItemPrice = (item: any): number => {
  const price = item.variation?.price ?? item.product?.price ?? 0
  return parseFloat(price)
}

// Helper to get original price (before discount)
const getItemOriginalPrice = (item: any): number => {
  const originalPrice = item.variation?.original_price ?? item.product?.original_price ?? item.variation?.price ?? item.product?.price ?? 0
  return parseFloat(originalPrice)
}

// Helper to check if item has discount
const hasDiscount = (item: any): boolean => {
  const currentPrice = getItemPrice(item)
  const originalPrice = getItemOriginalPrice(item)
  return originalPrice > currentPrice
}

// Helper to get item total (price * quantity)
const getItemTotal = (item: any): number => {
  return getItemPrice(item) * (item.quantity || 1)
}

// Helper to get original item total (original price * quantity)
const getItemOriginalTotal = (item: any): number => {
  return getItemOriginalPrice(item) * (item.quantity || 1)
}

// Use shared helper for max stock check
const checkMaxStock = isMaxStockReached

const handleCheckout = () => {
  // Navigate to checkout page
  router.push('/checkout')

  toast.add({
    title: 'Proceeding to checkout',
    description: 'Please complete your purchase',
    color: 'primary',
    icon: 'i-heroicons-shopping-bag'
  })
}

// SEO
useSEO({
  title: 'Shopping Cart',
  description: 'Review your cart and proceed to checkout'
})
</script>