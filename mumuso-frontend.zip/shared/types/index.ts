// types/index.ts
// Central export file for all types

// API types
export type { ApiResponse } from './api'

// Auth types
export type {
    AuthFormData,
    ProfileUpdateData,
    PasswordResetData,
    UserSession,
    BackendAuthResponse,
    User
} from './auth'

// Blog types
export type {
    BlogQueryParams,
    BlogPost,
    BlogCategory,
    BlogPostsResponse
} from './blog'

// Cart types
export type {
    CartItem,
    CartResponse,
    ApiErrorResponse,
    CartItemDiscount,
    CartItemPricing,
    AppliedDiscount,
    CartTotals
} from './cart'

export {
    hasProductDetails,
    getItemSlug,
    getItemName,
    getItemPrice,
    getItemOriginalPrice,
    getItemImage,
    getItemTotal,
    getItemOriginalTotal,
    hasDiscount
} from './cart'

// Product types
export type {
    Product,
    Pagination,
    ProductFilters,
    Category
} from './product'

// Review types
export type {
    ReviewSortBy,
    ReviewImage,
    Review,
    ReviewForm,
    ReviewStats,
    Purchase
} from './review'

// Content types
export type {
    HeroBanner,
    Category as ContentCategory
} from './content'

// Server types
export type {
    GuestCartData,
    GuestCartItem,
    CartErrorData
} from './server'

// Settings types
export type {
    Settings,
    BrandingSettings,
    SiteSettings,
    SEOSettings,
    CompanySettings,
    SocialMediaLink,
    FooterMenuItem,
    FooterSettings
} from './settings'

// Wishlist types
export type {
    WishlistItem
} from './wishlist'

// Payment types
export type {
    Payment,
    PaymentStatus,
    PaymentMethod,
    PaymentInitiateRequest,
    PaymentInitiateResponse,
    PaymentStatusResponse
} from './payment'
