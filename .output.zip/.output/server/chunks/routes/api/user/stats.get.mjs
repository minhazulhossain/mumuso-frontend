import { c as defineEventHandler, y as requireUserSession } from '../../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'consola';
import 'ipx';
import 'node:path';

const stats_get = defineEventHandler(async (event) => {
  const { user } = await requireUserSession(event);
  return {};
});

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
