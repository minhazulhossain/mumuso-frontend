import { c as defineEventHandler, u as useRuntimeConfig, g as getUserSession, e as createError, j as getRouterParam } from '../../../../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'consola';
import 'ipx';
import 'node:path';

const default_put = defineEventHandler(async (event) => {
  var _a, _b;
  const config = useRuntimeConfig();
  const session = await getUserSession(event);
  if (!((_a = session == null ? void 0 : session.user) == null ? void 0 : _a.token)) {
    throw createError({
      statusCode: 401,
      message: "Unauthorized"
    });
  }
  try {
    const id = getRouterParam(event, "id");
    return await $fetch(`${config.public.apiBase}user/addresses/${id}/default`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${session.user.token}`
      }
    });
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: ((_b = error.data) == null ? void 0 : _b.message) || "Failed to set default address"
    });
  }
});

export { default_put as default };
//# sourceMappingURL=default.put.mjs.map
