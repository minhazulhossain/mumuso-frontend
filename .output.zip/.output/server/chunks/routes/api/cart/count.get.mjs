import { c as defineEventHandler, q as getCartCount } from '../../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'consola';
import 'ipx';
import 'node:path';

const count_get = defineEventHandler(async (event) => {
  return {
    count: await getCartCount(event)
  };
});

export { count_get as default };
//# sourceMappingURL=count.get.mjs.map
