import { c as defineEventHandler, u as useRuntimeConfig, j as getRouterParam, e as createError } from '../../../../_/nitro.mjs';
import 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import '@iconify/utils';
import 'consola';
import 'ipx';
import 'node:path';

const _token__post = defineEventHandler(async (event) => {
  var _a;
  const config = useRuntimeConfig();
  const token = getRouterParam(event, "token");
  try {
    return await $fetch(`${config.public.apiBase}newsletter/unsubscribe/${token}`, {
      method: "POST",
      headers: {
        "Accept": "application/json"
      }
    });
  } catch (error) {
    throw createError({
      statusCode: error.statusCode || 500,
      message: ((_a = error.data) == null ? void 0 : _a.message) || "Unsubscribe failed"
    });
  }
});

export { _token__post as default };
//# sourceMappingURL=_token_.post.mjs.map
